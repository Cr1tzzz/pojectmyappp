package com.example.pomodoroapp

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Делаем статус-бар и панель навигации прозрачными
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            var currentTheme by remember { mutableStateOf(AppTheme.CLASSIC) }
            val backgroundColor by animateColorAsState(
                targetValue = currentTheme.bgColor,
                animationSpec = tween(durationMillis = 700),
                label = "bgColorAnim"
            )

            Surface(modifier = Modifier.fillMaxSize(), color = backgroundColor) {
                PomodoroFullApp(currentTheme) { selectedTheme -> currentTheme = selectedTheme }
            }
        }
    }
}

class BlockerService : AccessibilityService() {
    private val blockedApps = setOf(
        "org.telegram.messenger",
        "com.vkontakte.android",
        "com.instagram.android"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            val sharedPrefs = getSharedPreferences("PomodoroPrefs", Context.MODE_PRIVATE)
            val isFocusActive = sharedPrefs.getBoolean("is_focus_active", false)

            if (isFocusActive && blockedApps.contains(packageName)) {
                val currentCoins = sharedPrefs.getInt("user_coins", 0)
                if (currentCoins > 0) {
                    sharedPrefs.edit().putInt("user_coins", (currentCoins - 5).coerceAtLeast(0)).apply()
                }
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            }
        }
    }
    override fun onInterrupt() {}
}

object CustomIcons {
    val Play: ImageVector = ImageVector.Builder("Play", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color.White)) {
            moveTo(8f, 5f); lineTo(19f, 12f); lineTo(8f, 19f); close()
        }
    }.build()

    val Pause: ImageVector = ImageVector.Builder("Pause", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color.White)) {
            moveTo(6f, 19f); horizontalLineTo(10f); verticalLineTo(5f); horizontalLineTo(6f); close()
            moveTo(14f, 5f); verticalLineTo(19f); horizontalLineTo(18f); verticalLineTo(5f); close()
        }
    }.build()

    val Refresh: ImageVector = ImageVector.Builder("Refresh", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color.White)) {
            moveTo(17.65f, 6.35f)
            curveTo(16.2f, 4.9f, 14.21f, 4f, 12f, 4f)
            curveTo(7.58f, 4f, 4.01f, 7.58f, 4.01f, 12f)
            curveTo(4.01f, 16.42f, 7.58f, 20f, 12f, 20f)
            curveTo(15.73f, 20f, 18.84f, 17.45f, 19.73f, 14f)
            horizontalLineTo(17.65f)
            curveTo(16.83f, 16.33f, 14.61f, 18f, 12f, 18f)
            curveTo(8.69f, 18f, 6f, 15.31f, 6f, 12f)
            curveTo(6f, 8.69f, 8.69f, 6f, 12f, 6f)
            curveTo(13.66f, 6f, 15.14f, 6.69f, 16.22f, 7.78f)
            lineTo(13f, 11f); horizontalLineTo(20f); verticalLineTo(4f); close()
        }
    }.build()

    val ShoppingBag: ImageVector = ImageVector.Builder("ShoppingBag", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color.White)) {
            moveTo(18f, 6f); horizontalLineTo(16f)
            curveTo(16f, 3.79f, 14.21f, 2f, 12f, 2f)
            curveTo(9.79f, 2f, 8f, 3.79f, 8f, 6f)
            horizontalLineTo(6f)
            curveTo(4.9f, 6f, 4f, 6.9f, 4f, 8f)
            verticalLineTo(20f)
            curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f)
            horizontalLineTo(18f)
            curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f)
            verticalLineTo(8f)
            curveTo(20f, 6.9f, 19.1f, 6f, 18f, 6f); close()
            moveTo(12f, 4f)
            curveTo(13.1f, 4f, 14f, 4.9f, 14f, 6f)
            horizontalLineTo(10f)
            curveTo(10f, 4.9f, 10.9f, 4f, 12f, 4f); close()
        }
    }.build()

    val Trophy: ImageVector = ImageVector.Builder("Trophy", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color.White)) {
            moveTo(19f, 5f); horizontalLineTo(17f); verticalLineTo(3f); horizontalLineTo(7f); verticalLineTo(5f); horizontalLineTo(5f)
            curveTo(3.9f, 5f, 3f, 5.9f, 3f, 7f); verticalLineTo(8f)
            curveTo(3f, 10.55f, 4.92f, 12.63f, 7.39f, 12.94f)
            curveTo(8.02f, 14.44f, 9.37f, 15.57f, 11f, 15.9f)
            verticalLineTo(19f); horizontalLineTo(7f); verticalLineTo(21f); horizontalLineTo(17f); verticalLineTo(19f); horizontalLineTo(13f)
            verticalLineTo(15.9f)
            curveTo(14.63f, 15.57f, 15.98f, 14.44f, 16.61f, 12.94f)
            curveTo(19.08f, 12.63f, 21f, 10.55f, 21f, 8f)
            verticalLineTo(7f)
            curveTo(21f, 5.9f, 20.1f, 5f, 19f, 5f); close()
            moveTo(5f, 8f); verticalLineTo(7f); horizontalLineTo(7f); verticalLineTo(10.82f)
            curveTo(5.84f, 10.4f, 5f, 9.3f, 5f, 8f); close()
            moveTo(19f, 8f)
            curveTo(19f, 9.3f, 18.16f, 10.4f, 17f, 10.82f)
            verticalLineTo(7f); horizontalLineTo(19f); verticalLineTo(8f); close()
        }
    }.build()

    val Coin: ImageVector = ImageVector.Builder("Coin", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFD700))) {
            moveTo(12f, 2f)
            curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
            curveTo(2f, 17.52f, 6.48f, 22f, 12f, 22f)
            curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
            curveTo(22f, 6.48f, 17.52f, 2f, 12f, 2f); close()
            moveTo(13.5f, 16f); horizontalLineTo(10.5f); verticalLineTo(8f); horizontalLineTo(13.5f); verticalLineTo(16f); close()
        }
    }.build()

    val Shield: ImageVector = ImageVector.Builder("Shield", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = androidx.compose.ui.graphics.SolidColor(Color.White)) {
            moveTo(12f, 1f); lineTo(3f, 5f); verticalLineTo(11f)
            curveTo(3f, 16.55f, 6.84f, 21.74f, 12f, 23f)
            curveTo(17.16f, 21.74f, 21f, 16.55f, 21f, 11f)
            verticalLineTo(5f); lineTo(12f, 1f); close()
        }
    }.build()
}

enum class AppTheme(
    val title: String,
    val subtitle: String,
    val bgColor: Color,
    val secondaryBg: Color,
    val primaryColor: Color,
    val price: Int
) {
    CLASSIC("Классика", "Глубокий графит и рубин", Color(0xFF0F1016), Color(0xFF1C1E2B), Color(0xFFFF4B6E), 0),
    SPACE("Космос", "Туманность Андромеды", Color(0xFF090614), Color(0xFF1A103C), Color(0xFF9D4EDD), 30),
    FOREST("Лесная глушь", "Изумрудный туман", Color(0xFF08120E), Color(0xFF112920), Color(0xFF2EC4B6), 50),
    NEON("Киберпанк", "Ночной Найт-Сити", Color(0xFF100317), Color(0xFF280838), Color(0xFF00F5D4), 80)
}

enum class TimerMode(val title: String, val durationMinutes: Int) {
    FOCUS("Фокус", 25),
    SHORT_BREAK("Перерыв", 5),
    LONG_BREAK("Отдых", 15)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PomodoroFullApp(currentTheme: AppTheme, onThemeChanged: (AppTheme) -> Unit) {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("PomodoroPrefs", Context.MODE_PRIVATE) }

    var coins by remember { mutableIntStateOf(sharedPrefs.getInt("user_coins", 10)) }
    var currentMode by remember { mutableStateOf(TimerMode.FOCUS) }
    var timeLeft by remember { mutableIntStateOf(currentMode.durationMinutes * 60) }
    var isTimerRunning by remember { mutableStateOf(false) }
    var completedFocusSessions by remember { mutableIntStateOf(0) }
    var userTitle by remember { mutableStateOf("Новичок") }
    var showShop by remember { mutableStateOf(false) }
    val purchasedThemes = remember { mutableStateListOf(AppTheme.CLASSIC) }
    val primaryAnimated by animateColorAsState(currentTheme.primaryColor, tween(600), label = "primary")
    val secondaryBgAnimated by animateColorAsState(currentTheme.secondaryBg, tween(600), label = "secBg")
    val totalDuration = currentMode.durationMinutes * 60
    val rawProgress = if (totalDuration > 0) timeLeft.toFloat() / totalDuration else 0f
    val animatedProgress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "progress"
    )
// Пульсация свечения при активном таймере
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = if (isTimerRunning) 0.35f else 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )
    LaunchedEffect(Unit) {
        while (true) {
            coins = sharedPrefs.getInt("user_coins", coins)
            delay(1000)
        }
    }
    LaunchedEffect(isTimerRunning, currentMode) {
        if (!isTimerRunning) {
            sharedPrefs.edit().putBoolean("is_focus_active", false).apply()
            return@LaunchedEffect
        }
        sharedPrefs.edit().putBoolean("is_focus_active", currentMode == TimerMode.FOCUS).apply()
        while (timeLeft > 0 && isTimerRunning) {
            delay(1000)
            timeLeft--
        }
        if (timeLeft == 0 && isTimerRunning) {
            isTimerRunning = false
            sharedPrefs.edit().putBoolean("is_focus_active", false).apply()
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 500)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (currentMode == TimerMode.FOCUS) {
                val newCoins = coins + 15
                coins = newCoins
                sharedPrefs.edit().putInt("user_coins", newCoins).apply()
                completedFocusSessions++
                userTitle = when {
                    completedFocusSessions >= 15 -> "Магистр Времени"
                    completedFocusSessions >= 8 -> "Мудрец Фокуса"
                    completedFocusSessions >= 3 -> "Адепт Дисциплины"
                    else -> "Искатель"
                }
                currentMode = if (completedFocusSessions % 4 == 0) TimerMode.LONG_BREAK else TimerMode.SHORT_BREAK
            } else {
                currentMode = TimerMode.FOCUS
            }
            timeLeft = currentMode.durationMinutes * 60
        }
    }
// Градиентный фон всего экрана
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(secondaryBgAnimated, currentTheme.bgColor)
                )
            )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(primaryAnimated, CircleShape)
                            )
                            Text(
                                "POMODORO RPG",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                letterSpacing = 1.5.sp
                            )
                        }
                    },
                    actions = {
// Кнопка магазина в стиле Glassmorphism
                        Surface(
                            onClick = { showShop = true },
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    CustomIcons.ShoppingBag,
                                    contentDescription = "Магазин",
                                    tint = primaryAnimated,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("Темы", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            },
            containerColor = Color.Transparent
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
// 1. Карточка персонажа (RPG-профиль)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.White.copy(alpha = 0.06f),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.03f))
                        )
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .padding(18.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
// Аватар-бейдж ранга
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(primaryAnimated.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                                    .border(1.dp, primaryAnimated.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    CustomIcons.Trophy,
                                    contentDescription = null,
                                    tint = primaryAnimated,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = userTitle,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Сессий завершено: $completedFocusSessions",
                                    color = Color.White.copy(alpha = 0.55f),
                                    fontSize = 12.sp
                                )
                            }
                        }
// Счетчик монет
                        Surface(
                            color = Color(0xFFFFD700).copy(alpha = 0.12f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color(0xFFFFD700).copy(alpha = 0.3f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Icon(CustomIcons.Coin, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(18.dp))
                                Text("$coins", color = Color(0xFFFFD700), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
// 2. Центральный неоновый таймер
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(290.dp)) {
// Фоновое рассеянное свечение (Ambient Glow)
                    Box(
                        modifier = Modifier
                            .size(220.dp)
                            .blur(45.dp)
                            .background(primaryAnimated.copy(alpha = glowAlpha), CircleShape)
                    )
// Кастомный Canvas для идеального скругленного прогресса
                    Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                        val strokeWidth = 14.dp.toPx()
                        val diameter = size.minDimension - strokeWidth
                        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
                        val arcSize = Size(diameter, diameter)
// Фоновый трек
                        drawArc(
                            color = Color.White.copy(alpha = 0.07f),
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth)
                        )
// Активная дуга прогресса
                        drawArc(
                            color = primaryAnimated,
                            startAngle = -90f,
                            sweepAngle = 360f * animatedProgress,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
// Текст внутри таймера
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = String.format("%02d:%02d", timeLeft / 60, timeLeft % 60),
                            style = TextStyle(
                                fontSize = 64.sp,
                                fontWeight = FontWeight.Light,
                                color = Color.White,
                                fontFeatureSettings = "tnum" // Табличные цифры без дергания ширины
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = primaryAnimated.copy(alpha = 0.15f),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, primaryAnimated.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = currentMode.title.uppercase(),
                                color = primaryAnimated,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp),
                                letterSpacing = 2.sp
                            )
                        }
                    }
                }
// 3. Панель управления и режимы
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
// Переключатель режимов (Segmented Control)
                    Surface(
                        color = Color.White.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp)
                    ) {
                        Row(modifier = Modifier.padding(4.dp)) {
                            TimerMode.entries.forEach { mode ->
                                val isSelected = currentMode == mode
                                val tabBg by animateColorAsState(
                                    targetValue = if (isSelected) primaryAnimated else Color.Transparent,
                                    label = "tabBg"
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(tabBg)
                                        .clickable {
                                            isTimerRunning = false
                                            currentMode = mode
                                            timeLeft = mode.durationMinutes * 60
                                        }
                                        .padding(vertical = 11.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = mode.title,
                                        color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f),
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
// Главные кнопки: Старт/Пауза и Сброс
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { isTimerRunning = !isTimerRunning },
                            modifier = Modifier
                                .weight(1f)
                                .height(62.dp)
                                .shadow(
                                    elevation = 16.dp,
                                    shape = RoundedCornerShape(20.dp),
                                    ambientColor = primaryAnimated,
                                    spotColor = primaryAnimated
                                ),
                            colors = ButtonDefaults.buttonColors(containerColor = primaryAnimated),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Icon(
                                imageVector = if (isTimerRunning) CustomIcons.Pause else CustomIcons.Play,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isTimerRunning) "Пауза" else "Начать фокус",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Surface(
                            onClick = {
                                isTimerRunning = false
                                timeLeft = currentMode.durationMinutes * 60
                            },
                            modifier = Modifier.size(62.dp),
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White.copy(alpha = 0.07f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(CustomIcons.Refresh, contentDescription = "Сброс", tint = Color.White)
                            }
                        }
                    }
// Кнопка настройки блокировщика
                    TextButton(
                        onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        modifier = Modifier.padding(top = 10.dp)
                    ) {
                        Icon(
                            CustomIcons.Shield,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Настроить блокировку соцсетей",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
// Современный выдвижной магазин (BottomSheet) вместо устаревшего диалога
    if (showShop) {
        ModalBottomSheet(
            onDismissRequest = { showShop = false },
            containerColor = Color(0xFF161822),
            contentColor = Color.White,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 36.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Магазин тем", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
                    Surface(
                        color = Color(0xFFFFD700).copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(CustomIcons.Coin, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(16.dp))
                            Text("$coins", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(AppTheme.entries.toTypedArray()) { theme ->
                        val isPurchased = purchasedThemes.contains(theme)
                        val isSelected = currentTheme == theme
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color.White.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) theme.primaryColor else Color.White.copy(alpha = 0.08f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
// Превью цветов темы
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.linearGradient(listOf(theme.bgColor, theme.primaryColor))
                                            )
                                            .border(2.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                    )
                                    Column {
                                        Text(theme.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                                        Text(theme.subtitle, fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
                                    }
                                }
                                Button(
                                    onClick = {
                                        if (isPurchased) {
                                            onThemeChanged(theme)
                                        } else if (coins >= theme.price) {
                                            coins -= theme.price
                                            sharedPrefs.edit().putInt("user_coins", coins).apply()
                                            purchasedThemes.add(theme)
                                            onThemeChanged(theme)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) Color.White.copy(alpha = 0.15f) else theme.primaryColor,
                                        disabledContainerColor = Color.White.copy(alpha = 0.08f)
                                    ),
                                    enabled = isPurchased || coins >= theme.price,
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    if (!isPurchased) {
                                        Icon(CustomIcons.Coin, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${theme.price}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    } else {
                                        Text(
                                            text = if (isSelected) "Активна" else "Выбрать",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}